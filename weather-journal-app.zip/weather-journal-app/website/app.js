/* Global Variables */
// create the url of the open weather map page
const pageUrl ="https://api.openweathermap.org/data/2.5/weather?zip=";

//create a personal api and add &units=metric to get celisius temperature
const myApiKey= ",&appid=edeff51b56809a1244fb35ddf9961929&units=metric";

// server url
const serverURL = 'http://127.0.0.1:8000';
//attributing the error class
const error = document.getElementById("error");

// Create a new date instance dynamically with JS
let d = new Date();
let newDate ='('+ d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear()+')';

// geting the zip code and feelings from the user and the weather data from the open weather map page
function performAction() {
    const zip= document.getElementById("zip").value;
    const userFeelings= document.getElementById("feelings").value;

//fetching weather data and if there is an error the console out the error message
getWeatherData(zip).then((data)=> {
    if (data) {
        const {
           name: city, 
           main: {temp}, 
        }= data;
        //make a variable that contain all the data that i have fetched
        const fetchedData ={
            newDate,
            city,
            temp:Math.round(temp),
            userFeelings,
        };
        const postData= async (url="", fetchedData ={})=> {
    const res = await fetch (url,{
        method:'post',
        credentials:'same-origin',
        headers:{"Content-Type": "application/json",
    },
    //Making the fetched data as a string
    body:JSON.stringify(fetchedData),
    });
    try{
        const weatherData = await res.json();
        console.log(`Your new weather data`,weatherData);
        return weatherData;
    } catch(error){
        console.log(error);
    }
};
        postData(serverURL+"/add",fetchedData);
        updateUI();
    };
});
};
//make event listner to the generate button
document.getElementById("generate").addEventListener("click",performAction);
const getWeatherData = async (zip) => {
    try{ //making a test for any error
        const respond = await fetch (pageUrl+zip+myApiKey);
        const data = await respond.json();

        //cod 200 tell me that there is a respond from the openweathermap page by the data that i want to fetch and any other cod is equals error
        if (data.cod != 200){
            //make the error message appear in the inner HTML
            error.innerHTML=data.message;

            //setting time out for the message appearnce 
            setTimeout(_=> error.innerHTML='',1500);
        }
        return data;
    }catch (error){
        console.log(error);
    }
}; 

//fetching the weather data and put it in the inner HTML
const updateUI = async() =>{
const request = await fetch(serverURL+"/all");
try {
    const allData = await request.json();
    document.getElementById("date").innerHTML = allData.newDate;
    document.getElementById("city").innerHTML = allData.city;
    document.getElementById("temp").innerHTML = allData.temp+'&degC';
    document.getElementById("userFeelings").innerHTML = allData.userFeelings;
}catch (error) {
    console.log(error);
}
};
//make the editing >>const date = document.getElementById("date") 