# Weather-Journal App Project

## Overview
This project requires you to create an asynchronous web app that uses Web API and user data to dynamically update the UI. 

## Instructions
This will require modifying the `server.js` file and the `website/app.js` file. You can see `index.html` for element references, and once you are finished with the project steps, you can use `style.css` to style your application to customized perfection.

## Extras
If you are interested in testing your code as you go, you can use `tests.js` as a template for writing and running some basic tests for your code.
## References
- async and await functions:
https://www.w3schools.com/js/js_async.asp
- JSON.Stringify method:
https://www.w3schools.com/js/js_json_stringify.asp
- setTimeout method
https://www.w3schools.com/jsreF/met_win_settimeout.asp
- degree sign
https://www.w3schools.com/charsets/ref_html_entities_4.asp
- math.round method to make the weather degree integer not float
https://www.w3schools.com/jsref/jsref_round.asp
